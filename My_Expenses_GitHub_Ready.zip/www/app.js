const KEY='my-expenses-v1';
let expenses=JSON.parse(localStorage.getItem(KEY)||'[]');
const $=id=>document.getElementById(id);
const money=n=>'₹'+Number(n).toLocaleString('en-IN',{maximumFractionDigits:2});
const isoToday=()=>new Date().toISOString().slice(0,10);
const dateText=d=>new Date(d+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
function save(){localStorage.setItem(KEY,JSON.stringify(expenses))}
function sum(arr){return arr.reduce((a,x)=>a+Number(x.amount),0)}
function render(){
 const total=sum(expenses), today=isoToday(), month=today.slice(0,7);
 $('total').textContent=money(total);
 $('todayTotal').textContent=money(sum(expenses.filter(x=>x.date===today)));
 $('monthTotal').textContent=money(sum(expenses.filter(x=>x.date.startsWith(month))));
 $('groceryTotal').textContent=money(sum(expenses.filter(x=>x.category==='Grocery')));
 $('othersTotal').textContent=money(sum(expenses.filter(x=>x.category==='Others')));
 $('monthLabel').textContent=new Date().toLocaleDateString('en-IN',{month:'long',year:'numeric'});
 const filter=$('filter').value;
 const filtered=expenses.filter(x=>filter==='All'||x.category===filter).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
 const groups={}; filtered.forEach(x=>(groups[x.date]??=[]).push(x));
 $('list').innerHTML=Object.keys(groups).length?Object.entries(groups).map(([date,items])=>`
 <section class="day"><div class="day-head"><div class="day-title">${dateText(date)}</div><div class="day-total">Day total: ${money(sum(items))}</div></div>
 ${items.map(x=>`<div class="expense"><span class="dot"></span><div class="expense-main"><div class="cat">${x.category}</div>${x.details?`<div class="detail">${escapeHtml(x.details)}</div>`:''}</div><div class="expense-amount">${money(x.amount)}</div></div>`).join('')}</section>`).join(''):'<div class="empty">No expenses yet.<br>Add your first payment using the + button.</div>';
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
$('addBtn').onclick=()=>{$('date').value=isoToday();$('amount').value='';$('details').value='';$('modal').classList.remove('hidden');setTimeout(()=>$('amount').focus(),100)}
$('closeBtn').onclick=()=>$('modal').classList.add('hidden');
$('modal').onclick=e=>{if(e.target===$('modal'))$('modal').classList.add('hidden')};
$('filter').onchange=render;
$('expenseForm').onsubmit=e=>{e.preventDefault();const amount=Number($('amount').value);if(!(amount>0))return;expenses.push({id:crypto.randomUUID(),amount,date:$('date').value,category:$('category').value,details:$('details').value.trim(),createdAt:Date.now()});save();$('modal').classList.add('hidden');render()};
let deferred;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;$('installBtn').hidden=false});
$('installBtn').onclick=async()=>{if(deferred){deferred.prompt();await deferred.userChoice;deferred=null;$('installBtn').hidden=true}};
render();